--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.18 (Ubuntu 10.18-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.18 (Ubuntu 10.18-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.tra_gop DROP CONSTRAINT tra_gop_pk;
ALTER TABLE ONLY public.clv_kpi DROP CONSTRAINT clv_kpi_pk;
DROP TABLE public.users;
DROP TABLE public.tra_gop;
DROP TABLE public.thu_chi;
DROP TABLE public.specification;
DROP TABLE public.sale_supplier;
DROP TABLE public.sale_product_storage;
DROP TABLE public.sale_order_detail;
DROP TABLE public.sale_order;
DROP TABLE public.sale_dvvc;
DROP TABLE public.sale_category;
DROP SEQUENCE public.product_code_seq;
DROP TABLE public.sale_customer;
DROP TABLE public.danh_muc;
DROP TABLE public.clv_kpi;
DROP TABLE public.chi_tieu_email;
DROP TABLE public.chi_tieu;
DROP TABLE public.banks;
DROP EXTENSION adminpack;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: banks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banks (
    id smallint NOT NULL,
    name character varying,
    type character varying,
    cardtype character varying
);


ALTER TABLE public.banks OWNER TO postgres;

--
-- Name: chi_tieu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chi_tieu (
    id smallint NOT NULL,
    noi_dung character varying,
    so_tien numeric,
    ghi_chu character varying,
    danh_muc character varying,
    create_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    create_user integer,
    update_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    balance_in_month numeric,
    ngay_chi timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ky_chi character varying,
    bank_code character varying,
    status character varying DEFAULT 'DN'::character varying,
    mua_giup character varying,
    muc_dich character varying DEFAULT 'GD'::character varying,
    note_saoke character varying,
    ngay_sao_ke timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ngay_thanh_toan timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.chi_tieu OWNER TO postgres;

--
-- Name: COLUMN chi_tieu.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.chi_tieu.id IS 'ID';


--
-- Name: COLUMN chi_tieu.so_tien; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.chi_tieu.so_tien IS 'So tien chi';


--
-- Name: COLUMN chi_tieu.balance_in_month; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.chi_tieu.balance_in_month IS 'So tien con lai trong thang';


--
-- Name: COLUMN chi_tieu.ky_chi; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.chi_tieu.ky_chi IS 'Kỳ thẻ tín dụng';


--
-- Name: COLUMN chi_tieu.bank_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.chi_tieu.bank_code IS 'Ngân hàng chi tiêu';


--
-- Name: COLUMN chi_tieu.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.chi_tieu.status IS 'DCHI Dự Chi
,CHM: Cho Mượn
,DTT: Đã Tất Toán
,DN Dư Nợ
,DTCSK: Đã Trả / CSK
,DTN: Đã trả nợ
,NHT: Nhận tiền
,HTN: Hoàn Tiền
,MNT: Mượn Tiền';


--
-- Name: COLUMN chi_tieu.muc_dich; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.chi_tieu.muc_dich IS 'KINH DOANH
GIA ĐÌNH
CÁ NHÂN
CHO MƯỢN
GĐ-ANH EM';


--
-- Name: chi_tieu_email; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chi_tieu_email (
    id smallint NOT NULL,
    noi_dung character varying,
    so_tien numeric,
    ghi_chu character varying,
    create_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    create_user integer,
    update_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    balance_in_month numeric,
    ngay_chi timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ky_chi character varying,
    bank_code character varying,
    status character varying DEFAULT 'DN'::character varying,
    mua_giup character varying,
    muc_dich character varying DEFAULT 'GD'::character varying,
    isaddchitieu boolean DEFAULT false,
    email_subject character varying,
    email_content text,
    status_transaction character varying,
    ngay_mua character varying,
    email_sender character varying,
    email_id character varying
);


ALTER TABLE public.chi_tieu_email OWNER TO postgres;

--
-- Name: COLUMN chi_tieu_email.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.chi_tieu_email.id IS 'ID';


--
-- Name: COLUMN chi_tieu_email.so_tien; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.chi_tieu_email.so_tien IS 'So tien chi';


--
-- Name: COLUMN chi_tieu_email.balance_in_month; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.chi_tieu_email.balance_in_month IS 'So tien con lai trong thang';


--
-- Name: COLUMN chi_tieu_email.bank_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.chi_tieu_email.bank_code IS 'Ng�n h�ng chi ti�u ';


--
-- Name: chi_tieu_email_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.chi_tieu_email ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.chi_tieu_email_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: chi_tieu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.chi_tieu ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.chi_tieu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clv_kpi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clv_kpi (
    id integer NOT NULL,
    member character varying NOT NULL,
    "jsonKPI" text,
    "monthNum" integer DEFAULT 1 NOT NULL,
    "weekNum" integer DEFAULT 1 NOT NULL,
    "yearNum" integer DEFAULT 2021 NOT NULL,
    ticketid character varying NOT NULL,
    logtime double precision DEFAULT 0,
    tickettitle character varying,
    create_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    account character varying NOT NULL
);


ALTER TABLE public.clv_kpi OWNER TO postgres;

--
-- Name: clv_kpi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.clv_kpi ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.clv_kpi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: danh_muc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.danh_muc (
    id smallint NOT NULL,
    ten_dm character varying,
    ghi_chu character varying,
    ma_dm character(10) NOT NULL
);


ALTER TABLE public.danh_muc OWNER TO postgres;

--
-- Name: COLUMN danh_muc.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.danh_muc.id IS 'ID';


--
-- Name: danh_muc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.danh_muc ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.danh_muc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sale_customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sale_customer (
    id smallint NOT NULL,
    name character varying,
    address character varying,
    phone_number character varying,
    address_final_order character varying,
    note character varying
);


ALTER TABLE public.sale_customer OWNER TO postgres;

--
-- Name: COLUMN sale_customer.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_customer.id IS 'ID';


--
-- Name: COLUMN sale_customer.note; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_customer.note IS 'ghi ch�';


--
-- Name: khach_hang_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sale_customer ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.khach_hang_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: product_code_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_code_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_code_seq OWNER TO postgres;

--
-- Name: sale_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sale_category (
    id smallint NOT NULL,
    name character varying,
    note character varying,
    code character varying
);


ALTER TABLE public.sale_category OWNER TO postgres;

--
-- Name: COLUMN sale_category.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_category.id IS 'ID';


--
-- Name: sale_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sale_category ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sale_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sale_dvvc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sale_dvvc (
    id smallint NOT NULL,
    name character varying,
    address character varying,
    phone_number character varying,
    url_tracking character varying,
    "user" character varying,
    pwd character varying,
    token character varying
);


ALTER TABLE public.sale_dvvc OWNER TO postgres;

--
-- Name: COLUMN sale_dvvc.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_dvvc.id IS 'ID';


--
-- Name: COLUMN sale_dvvc."user"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_dvvc."user" IS 'ghi ch�';


--
-- Name: COLUMN sale_dvvc.pwd; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_dvvc.pwd IS 'ghi ch�';


--
-- Name: COLUMN sale_dvvc.token; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_dvvc.token IS 'ghi ch�';


--
-- Name: sale_dvvc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sale_dvvc ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sale_dvvc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sale_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sale_order (
    id smallint NOT NULL,
    order_code character varying,
    name_delivery character varying,
    address_delivery character varying,
    phone_delivery character varying,
    note character varying,
    customer_id character varying,
    total character varying,
    create_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    create_user integer,
    update_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    time_delivery character varying,
    delivery_status_code text DEFAULT 'NEW'::text,
    delivery_tracking character varying,
    delivery_phone_shipper character varying,
    delivery_partner character varying,
    delivery_url character varying,
    order_customer_type character varying,
    delivery_status_value real DEFAULT 0,
    payment_type character varying,
    payment_info json
);


ALTER TABLE public.sale_order OWNER TO postgres;

--
-- Name: COLUMN sale_order.delivery_tracking; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_order.delivery_tracking IS 'MA VAN CHUYEN';


--
-- Name: COLUMN sale_order.delivery_phone_shipper; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_order.delivery_phone_shipper IS 'SO DT SHIPPER';


--
-- Name: COLUMN sale_order.delivery_partner; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_order.delivery_partner IS 'HANG VAN CHUYEN';


--
-- Name: COLUMN sale_order.delivery_url; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_order.delivery_url IS 'LINK';


--
-- Name: sale_order_detail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sale_order_detail (
    id smallint NOT NULL,
    order_code character varying,
    product_code character varying,
    price numeric DEFAULT 0,
    quanity numeric DEFAULT 0,
    amount numeric DEFAULT 0,
    product_name character varying,
    size character varying,
    create_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    create_user integer,
    update_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    order_id integer
);


ALTER TABLE public.sale_order_detail OWNER TO postgres;

--
-- Name: sale_order_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sale_order_detail ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sale_order_detail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sale_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sale_order ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sale_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sale_product_storage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sale_product_storage (
    id smallint NOT NULL,
    product_code character varying,
    receipt_price numeric DEFAULT 0,
    previous_price numeric DEFAULT 0,
    note text,
    stock_current numeric DEFAULT 0,
    create_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    create_user integer,
    update_date timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    receipt_spec character varying,
    receipt_suppiler json,
    receipt_quatity numeric
);


ALTER TABLE public.sale_product_storage OWNER TO postgres;

--
-- Name: COLUMN sale_product_storage.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_product_storage.id IS 'ID';


--
-- Name: COLUMN sale_product_storage.note; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_product_storage.note IS 'Ghi ch�';


--
-- Name: sale_product_storage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sale_product_storage ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sale_product_storage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sale_supplier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sale_supplier (
    id smallint NOT NULL,
    name character varying,
    address character varying,
    phone_number character varying,
    address_final_order character varying,
    note character varying,
    code character varying
);


ALTER TABLE public.sale_supplier OWNER TO postgres;

--
-- Name: COLUMN sale_supplier.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_supplier.id IS 'ID';


--
-- Name: COLUMN sale_supplier.note; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sale_supplier.note IS 'ghi ch�';


--
-- Name: sale_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sale_supplier ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sale_supplier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: specification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.specification (
    id smallint NOT NULL,
    code character varying,
    name character varying,
    note text,
    type integer
);


ALTER TABLE public.specification OWNER TO postgres;

--
-- Name: COLUMN specification.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.specification.id IS 'ID';


--
-- Name: specification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.specification ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.specification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: thu_chi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.thu_chi (
    id smallint NOT NULL,
    noi_dung character varying,
    so_tien numeric,
    ghi_chu character varying,
    danh_muc character varying,
    create_date date DEFAULT now() NOT NULL,
    create_user integer,
    update_date date DEFAULT now() NOT NULL,
    con_lai numeric
);


ALTER TABLE public.thu_chi OWNER TO postgres;

--
-- Name: COLUMN thu_chi.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.thu_chi.id IS 'ID';


--
-- Name: COLUMN thu_chi.so_tien; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.thu_chi.so_tien IS 'Credit or Debit';


--
-- Name: thu_chi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.thu_chi ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.thu_chi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tra_gop; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tra_gop (
    id smallint NOT NULL,
    san_pham character varying,
    bank character varying,
    tong_tien numeric,
    moi_ky numeric,
    tong_so_ky integer,
    ky_da_tra integer,
    ky_con_lai integer,
    tien_do_tra_gop numeric,
    noi_mua character varying,
    ngay_mua date NOT NULL,
    ghi_chu character varying,
    ky_cuoi date,
    trang_thai character varying,
    ky_dau date,
    chitieulist json
);


ALTER TABLE public.tra_gop OWNER TO postgres;

--
-- Name: COLUMN tra_gop.chitieulist; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tra_gop.chitieulist IS 'List JSON chi tieu';


--
-- Name: tra_gop_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tra_gop ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tra_gop_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    usr_nm character varying NOT NULL,
    usr_pwd character varying NOT NULL,
    notes character varying,
    status integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: banks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banks (id, name, type, cardtype) FROM stdin;
\.
COPY public.banks (id, name, type, cardtype) FROM '$$PATH$$/3082.dat';

--
-- Data for Name: chi_tieu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chi_tieu (id, noi_dung, so_tien, ghi_chu, danh_muc, create_date, create_user, update_date, balance_in_month, ngay_chi, ky_chi, bank_code, status, mua_giup, muc_dich, note_saoke, ngay_sao_ke, ngay_thanh_toan) FROM stdin;
\.
COPY public.chi_tieu (id, noi_dung, so_tien, ghi_chu, danh_muc, create_date, create_user, update_date, balance_in_month, ngay_chi, ky_chi, bank_code, status, mua_giup, muc_dich, note_saoke, ngay_sao_ke, ngay_thanh_toan) FROM '$$PATH$$/3084.dat';

--
-- Data for Name: chi_tieu_email; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chi_tieu_email (id, noi_dung, so_tien, ghi_chu, create_date, create_user, update_date, balance_in_month, ngay_chi, ky_chi, bank_code, status, mua_giup, muc_dich, isaddchitieu, email_subject, email_content, status_transaction, ngay_mua, email_sender, email_id) FROM stdin;
\.
COPY public.chi_tieu_email (id, noi_dung, so_tien, ghi_chu, create_date, create_user, update_date, balance_in_month, ngay_chi, ky_chi, bank_code, status, mua_giup, muc_dich, isaddchitieu, email_subject, email_content, status_transaction, ngay_mua, email_sender, email_id) FROM '$$PATH$$/3053.dat';

--
-- Data for Name: clv_kpi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clv_kpi (id, member, "jsonKPI", "monthNum", "weekNum", "yearNum", ticketid, logtime, tickettitle, create_date, account) FROM stdin;
\.
COPY public.clv_kpi (id, member, "jsonKPI", "monthNum", "weekNum", "yearNum", ticketid, logtime, tickettitle, create_date, account) FROM '$$PATH$$/3055.dat';

--
-- Data for Name: danh_muc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.danh_muc (id, ten_dm, ghi_chu, ma_dm) FROM stdin;
\.
COPY public.danh_muc (id, ten_dm, ghi_chu, ma_dm) FROM '$$PATH$$/3057.dat';

--
-- Data for Name: sale_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sale_category (id, name, note, code) FROM stdin;
\.
COPY public.sale_category (id, name, note, code) FROM '$$PATH$$/3062.dat';

--
-- Data for Name: sale_customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sale_customer (id, name, address, phone_number, address_final_order, note) FROM stdin;
\.
COPY public.sale_customer (id, name, address, phone_number, address_final_order, note) FROM '$$PATH$$/3059.dat';

--
-- Data for Name: sale_dvvc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sale_dvvc (id, name, address, phone_number, url_tracking, "user", pwd, token) FROM stdin;
\.
COPY public.sale_dvvc (id, name, address, phone_number, url_tracking, "user", pwd, token) FROM '$$PATH$$/3064.dat';

--
-- Data for Name: sale_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sale_order (id, order_code, name_delivery, address_delivery, phone_delivery, note, customer_id, total, create_date, create_user, update_date, time_delivery, delivery_status_code, delivery_tracking, delivery_phone_shipper, delivery_partner, delivery_url, order_customer_type, delivery_status_value, payment_type, payment_info) FROM stdin;
\.
COPY public.sale_order (id, order_code, name_delivery, address_delivery, phone_delivery, note, customer_id, total, create_date, create_user, update_date, time_delivery, delivery_status_code, delivery_tracking, delivery_phone_shipper, delivery_partner, delivery_url, order_customer_type, delivery_status_value, payment_type, payment_info) FROM '$$PATH$$/3066.dat';

--
-- Data for Name: sale_order_detail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sale_order_detail (id, order_code, product_code, price, quanity, amount, product_name, size, create_date, create_user, update_date, order_id) FROM stdin;
\.
COPY public.sale_order_detail (id, order_code, product_code, price, quanity, amount, product_name, size, create_date, create_user, update_date, order_id) FROM '$$PATH$$/3067.dat';

--
-- Data for Name: sale_product_storage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sale_product_storage (id, product_code, receipt_price, previous_price, note, stock_current, create_date, create_user, update_date, receipt_spec, receipt_suppiler, receipt_quatity) FROM stdin;
\.
COPY public.sale_product_storage (id, product_code, receipt_price, previous_price, note, stock_current, create_date, create_user, update_date, receipt_spec, receipt_suppiler, receipt_quatity) FROM '$$PATH$$/3070.dat';

--
-- Data for Name: sale_supplier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sale_supplier (id, name, address, phone_number, address_final_order, note, code) FROM stdin;
\.
COPY public.sale_supplier (id, name, address, phone_number, address_final_order, note, code) FROM '$$PATH$$/3072.dat';

--
-- Data for Name: specification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.specification (id, code, name, note, type) FROM stdin;
\.
COPY public.specification (id, code, name, note, type) FROM '$$PATH$$/3074.dat';

--
-- Data for Name: thu_chi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.thu_chi (id, noi_dung, so_tien, ghi_chu, danh_muc, create_date, create_user, update_date, con_lai) FROM stdin;
\.
COPY public.thu_chi (id, noi_dung, so_tien, ghi_chu, danh_muc, create_date, create_user, update_date, con_lai) FROM '$$PATH$$/3076.dat';

--
-- Data for Name: tra_gop; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tra_gop (id, san_pham, bank, tong_tien, moi_ky, tong_so_ky, ky_da_tra, ky_con_lai, tien_do_tra_gop, noi_mua, ngay_mua, ghi_chu, ky_cuoi, trang_thai, ky_dau, chitieulist) FROM stdin;
\.
COPY public.tra_gop (id, san_pham, bank, tong_tien, moi_ky, tong_so_ky, ky_da_tra, ky_con_lai, tien_do_tra_gop, noi_mua, ngay_mua, ghi_chu, ky_cuoi, trang_thai, ky_dau, chitieulist) FROM '$$PATH$$/3078.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, usr_nm, usr_pwd, notes, status) FROM stdin;
\.
COPY public.users (id, usr_nm, usr_pwd, notes, status) FROM '$$PATH$$/3080.dat';

--
-- Name: chi_tieu_email_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.chi_tieu_email_id_seq', 1533, true);


--
-- Name: chi_tieu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.chi_tieu_id_seq', 428, true);


--
-- Name: clv_kpi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clv_kpi_id_seq', 179, true);


--
-- Name: danh_muc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.danh_muc_id_seq', 3, true);


--
-- Name: khach_hang_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.khach_hang_id_seq', 21, true);


--
-- Name: product_code_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_code_seq', 1190, true);


--
-- Name: sale_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sale_category_id_seq', 6, true);


--
-- Name: sale_dvvc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sale_dvvc_id_seq', 9, true);


--
-- Name: sale_order_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sale_order_detail_id_seq', 448, true);


--
-- Name: sale_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sale_order_id_seq', 289, true);


--
-- Name: sale_product_storage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sale_product_storage_id_seq', 34, true);


--
-- Name: sale_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sale_supplier_id_seq', 6, true);


--
-- Name: specification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.specification_id_seq', 26, true);


--
-- Name: thu_chi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.thu_chi_id_seq', 2, true);


--
-- Name: tra_gop_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tra_gop_id_seq', 19, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: clv_kpi clv_kpi_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clv_kpi
    ADD CONSTRAINT clv_kpi_pk PRIMARY KEY (id);


--
-- Name: tra_gop tra_gop_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tra_gop
    ADD CONSTRAINT tra_gop_pk PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

